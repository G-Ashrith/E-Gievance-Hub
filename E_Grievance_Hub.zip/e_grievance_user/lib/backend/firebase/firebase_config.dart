import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCHomKE1pGydzJScZZ48kWDdhbLk-EK-Ek",
            authDomain: "login-app-iqbm77.firebaseapp.com",
            projectId: "login-app-iqbm77",
            storageBucket: "login-app-iqbm77.appspot.com",
            messagingSenderId: "863757030959",
            appId: "1:863757030959:web:194a4d06b1a78f566318da"));
  } else {
    await Firebase.initializeApp();
  }
}
