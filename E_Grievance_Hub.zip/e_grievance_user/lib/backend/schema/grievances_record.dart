import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class GrievancesRecord extends FirestoreRecord {
  GrievancesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userId" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "grevtype" field.
  String? _grevtype;
  String get grevtype => _grevtype ?? '';
  bool hasGrevtype() => _grevtype != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "authid" field.
  String? _authid;
  String get authid => _authid ?? '';
  bool hasAuthid() => _authid != null;

  // "state" field.
  bool? _state;
  bool get state => _state ?? false;
  bool hasState() => _state != null;

  // "authdescription" field.
  String? _authdescription;
  String get authdescription => _authdescription ?? '';
  bool hasAuthdescription() => _authdescription != null;

  // "solvedtimestamp" field.
  DateTime? _solvedtimestamp;
  DateTime? get solvedtimestamp => _solvedtimestamp;
  bool hasSolvedtimestamp() => _solvedtimestamp != null;

  // "solved_notsolved" field.
  bool? _solvedNotsolved;
  bool get solvedNotsolved => _solvedNotsolved ?? false;
  bool hasSolvedNotsolved() => _solvedNotsolved != null;

  // "rating" field.
  int? _rating;
  int get rating => _rating ?? 0;
  bool hasRating() => _rating != null;

  // "usercomment" field.
  String? _usercomment;
  String get usercomment => _usercomment ?? '';
  bool hasUsercomment() => _usercomment != null;

  // "grevtitle" field.
  String? _grevtitle;
  String get grevtitle => _grevtitle ?? '';
  bool hasGrevtitle() => _grevtitle != null;

  // "User_satisfiedornot" field.
  bool? _userSatisfiedornot;
  bool get userSatisfiedornot => _userSatisfiedornot ?? false;
  bool hasUserSatisfiedornot() => _userSatisfiedornot != null;

  // "audio_recording" field.
  String? _audioRecording;
  String get audioRecording => _audioRecording ?? '';
  bool hasAudioRecording() => _audioRecording != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  void _initializeFields() {
    _userId = snapshotData['userId'] as String?;
    _grevtype = snapshotData['grevtype'] as String?;
    _description = snapshotData['description'] as String?;
    _location = snapshotData['location'] as LatLng?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _city = snapshotData['city'] as String?;
    _image = snapshotData['image'] as String?;
    _authid = snapshotData['authid'] as String?;
    _state = snapshotData['state'] as bool?;
    _authdescription = snapshotData['authdescription'] as String?;
    _solvedtimestamp = snapshotData['solvedtimestamp'] as DateTime?;
    _solvedNotsolved = snapshotData['solved_notsolved'] as bool?;
    _rating = castToType<int>(snapshotData['rating']);
    _usercomment = snapshotData['usercomment'] as String?;
    _grevtitle = snapshotData['grevtitle'] as String?;
    _userSatisfiedornot = snapshotData['User_satisfiedornot'] as bool?;
    _audioRecording = snapshotData['audio_recording'] as String?;
    _address = snapshotData['address'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('grievances');

  static Stream<GrievancesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => GrievancesRecord.fromSnapshot(s));

  static Future<GrievancesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => GrievancesRecord.fromSnapshot(s));

  static GrievancesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      GrievancesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static GrievancesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      GrievancesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'GrievancesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is GrievancesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createGrievancesRecordData({
  String? userId,
  String? grevtype,
  String? description,
  LatLng? location,
  DateTime? timestamp,
  String? city,
  String? image,
  String? authid,
  bool? state,
  String? authdescription,
  DateTime? solvedtimestamp,
  bool? solvedNotsolved,
  int? rating,
  String? usercomment,
  String? grevtitle,
  bool? userSatisfiedornot,
  String? audioRecording,
  String? address,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userId': userId,
      'grevtype': grevtype,
      'description': description,
      'location': location,
      'timestamp': timestamp,
      'city': city,
      'image': image,
      'authid': authid,
      'state': state,
      'authdescription': authdescription,
      'solvedtimestamp': solvedtimestamp,
      'solved_notsolved': solvedNotsolved,
      'rating': rating,
      'usercomment': usercomment,
      'grevtitle': grevtitle,
      'User_satisfiedornot': userSatisfiedornot,
      'audio_recording': audioRecording,
      'address': address,
    }.withoutNulls,
  );

  return firestoreData;
}

class GrievancesRecordDocumentEquality implements Equality<GrievancesRecord> {
  const GrievancesRecordDocumentEquality();

  @override
  bool equals(GrievancesRecord? e1, GrievancesRecord? e2) {
    return e1?.userId == e2?.userId &&
        e1?.grevtype == e2?.grevtype &&
        e1?.description == e2?.description &&
        e1?.location == e2?.location &&
        e1?.timestamp == e2?.timestamp &&
        e1?.city == e2?.city &&
        e1?.image == e2?.image &&
        e1?.authid == e2?.authid &&
        e1?.state == e2?.state &&
        e1?.authdescription == e2?.authdescription &&
        e1?.solvedtimestamp == e2?.solvedtimestamp &&
        e1?.solvedNotsolved == e2?.solvedNotsolved &&
        e1?.rating == e2?.rating &&
        e1?.usercomment == e2?.usercomment &&
        e1?.grevtitle == e2?.grevtitle &&
        e1?.userSatisfiedornot == e2?.userSatisfiedornot &&
        e1?.audioRecording == e2?.audioRecording &&
        e1?.address == e2?.address;
  }

  @override
  int hash(GrievancesRecord? e) => const ListEquality().hash([
        e?.userId,
        e?.grevtype,
        e?.description,
        e?.location,
        e?.timestamp,
        e?.city,
        e?.image,
        e?.authid,
        e?.state,
        e?.authdescription,
        e?.solvedtimestamp,
        e?.solvedNotsolved,
        e?.rating,
        e?.usercomment,
        e?.grevtitle,
        e?.userSatisfiedornot,
        e?.audioRecording,
        e?.address
      ]);

  @override
  bool isValidKey(Object? o) => o is GrievancesRecord;
}
