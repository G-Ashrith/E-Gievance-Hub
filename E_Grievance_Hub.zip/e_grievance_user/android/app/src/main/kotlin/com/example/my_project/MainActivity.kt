package com.mycompany.EGrievanceHub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
